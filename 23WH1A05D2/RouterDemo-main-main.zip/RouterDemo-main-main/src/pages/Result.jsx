const Result = () => {
    return (
        <h1>Deserunt incididunt qui dolor aliqua proident anim laboris tempor incididunt ex eiusmod consequat sint.</h1>
    )
}
export default Result
import React from "react";
import { Link } from "react-router";
import './styles.css'

const Home = () => {
  return (
    <div className="container">
      <h1>Hi!! This is Home Page</h1>
    </div>
  );
};

export default Home;

import React from 'react';
import './styles.css';
const About = () => {
  return (
    <div className="about">
      <h1>About Us</h1>
      <h2>Empowering Women to Engineer a Better Future.</h2>
      <p>BVRIT HYDERABAD College of Engineering for Women is the youngest college under the umbrella of Sri Vishnu Educational Society, Established in 2012, with the intention of enabling women engineers to reach greater heights, it has already acquired many accolades in academics, placements and technical competitions. With exceptional results of very first batch, BVRIT HYDERABAD is now one of the most sought after institute in Hyderabad for prospective engineering students.</p>
    </div>
  );
};

export default About;

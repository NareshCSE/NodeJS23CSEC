import React from 'react';
import { useNavigate } from 'react-router';
import './styles.css';

const SignUp = () => {
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevents the default form submission behavior
    navigate('/result');
  };

  return (
    <div className="contact">
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="fname">First Name:</label>
          <input type="text" id="fname" name="fname" placeholder="Full name" required />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" placeholder="Enter email" required />
        </div>
        <div className="form-group">
          <label htmlFor="mobileno">Mobile Number:</label>
          <input type="tel" id="mobileno" name="mobileno" placeholder="Enter phone number" pattern="[0-9]{10}" required />
        </div>
        <div className="form-group">
          <label htmlFor="dob">Date of Birth:</label>

          <input type="date" id="dob" name="dob" />

        </div>
        <div class="form-group">
          <label htmlFor="gender">Gender:</label>
          <input type="radio" id="gender1" name="gender" value="MALE" class="form-check-input" />
          <label htmlFor="gender1" class="form-check-label">Male</label>


          <input type="radio" id="gender2" name="gender" value="FEMALE" class="form-check-input" />
          <label htmlFor="gender2" class="form-check-label">Female</label>

        </div>

        {/* <div className="form-group">
          <div >
            <label for="password">Enter Password:</label>
          </div>
          <div >
            <input type="password" id="password" name="password" placeholder="Enter password" class="form-control mb-2" required />
          </div>
        </div>
        <div className="form-group">
          <div >
            <label htmlFor="repassword">Confirm Password:</label>
          </div>
          <div >
            <input type="password" id="repassword" name="repassword" placeholder="Confirm Password" class="form-control mb-2" required />
          </div>
        </div> */}

        <div className="form-group">
          <label htmlFor="department">Department:</label>
          <div>
            <select id="department" name="department">
              <option value="CSE">CSE</option>
              <option value="IT">IT</option>
              <option value="ECE">ECE</option>
              <option value="EEE">EEE</option>
            </select>
          </div>
        </div>
        <div className="form-group">
          <button type="submit">Submit</button>
          <button type="reset">Reset</button>
        </div>

      </form>
    </div>
  );
};

export default SignUp;

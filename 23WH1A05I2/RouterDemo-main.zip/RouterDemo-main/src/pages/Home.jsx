import React from 'react';

const Home = () => {
  return (
    <div className="home">
      <h1>Welcome to BVRIT HYDERABAD College Of Engineering For Women</h1>
    </div>
  );
};

export default Home;
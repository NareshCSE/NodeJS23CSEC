package com.bvrith.ebook.ebookbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.bvrith.ebook.ebookbackend.model;
import jakarta.persistence.*;
@Entity
@Table(name = "book")
public class Book {
	@Id 
	@Column(name = "book_id")
	private int book_id;
	@Column(name = "bookname")
	private String bookname;
	@Column(name = "bookdetails")
	private String bookdetails;
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getBookdetails() {
		return bookdetails;
	}
	public void setBookdetails(String bookdetails) {
		this.bookdetails = bookdetails;
	}
	
}

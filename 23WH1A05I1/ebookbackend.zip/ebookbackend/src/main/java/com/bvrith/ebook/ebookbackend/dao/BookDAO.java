package com.bvrith.ebook.ebookbackend.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.bvrith.ebook.ebookbackend.model.Book;
public interface BookDAO extends JpaRepository<Book,Integer>{
	
}

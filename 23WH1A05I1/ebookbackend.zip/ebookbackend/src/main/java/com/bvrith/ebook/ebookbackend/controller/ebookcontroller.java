package com.bvrith.ebook.ebookbackend.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.bvrith.ebook.ebookbackend.dao.*;
import com.bvrith.ebook.ebookbackend.model.Book;
@RestController
public class ebookcontroller {
	   @Autowired
	   private BookDAO bookDAO;
	   
       @GetMapping("/getAllBooks")
       public List<Book> getBooks()
       {
    	   return bookDAO.findAll();
       }
}

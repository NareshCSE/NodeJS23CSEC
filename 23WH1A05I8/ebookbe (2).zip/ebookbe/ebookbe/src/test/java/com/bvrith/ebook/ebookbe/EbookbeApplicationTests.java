package com.bvrith.ebook.ebookbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookbeApplicationTests {

	@Test
	void contextLoads() {
	}

}

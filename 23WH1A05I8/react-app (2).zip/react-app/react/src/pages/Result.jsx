import React from 'react';

const Result = () => {
    return (
        <p> Thanks for visiting </p>
    )
}
export default Result;
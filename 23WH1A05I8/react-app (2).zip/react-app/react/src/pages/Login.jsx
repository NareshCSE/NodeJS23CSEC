import React from 'react';
import './styles.css';
const Login = () => {
    return (
        <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input type="text" id="email" name="email" placeholder="Enter Email/Mobile no" required />
            <br/>
            <br/>

            <label htmlFor="password">Password</label>
            <input type="text" id="password" name="password" placeholder="Enter password" required />
            <br />
            <br/>
            <a href="">Forgot Password</a>
            <br/>
            <br/>
            <button>Login</button>
        </div>

    )
}
export default Login;
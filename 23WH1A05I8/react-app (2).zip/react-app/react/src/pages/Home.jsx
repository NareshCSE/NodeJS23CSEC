const Home = () => {
  return (
    <div className="home">
      <h1>Welcome to BVRIT Hyderabad College of Engineering for Women</h1>
    </div>
  );
};

export default Home;
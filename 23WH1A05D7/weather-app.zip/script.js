const API_KEY = 'YOUR_API_KEY'; // Replace with your OpenWeatherMap API key

const getWeather = async () => {
  const city = document.getElementById('city').value;
  if (!city) return alert("Please enter a city");

  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${API_KEY}`
    );
    const data = await response.json();

    const labels = data.list.slice(0, 6).map(item =>
      new Date(item.dt_txt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    );

    const temps = data.list.slice(0, 6).map(item => item.main.temp);

    renderChart(labels, temps);
  } catch (err) {
    console.error("Error fetching weather:", err);
    alert("Failed to fetch weather data.");
  }
};

let chart;

const renderChart = (labels, temps) => {
  const ctx = document.getElementById("weatherChart").getContext("2d");

  if (chart) {
    chart.destroy(); // destroy previous chart if exists
  }

  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Temperature (°C)',
        data: temps,
        backgroundColor: 'rgba(30, 144, 255, 0.2)',
        borderColor: 'dodgerblue',
        borderWidth: 2,
        fill: true,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: false
        }
      }
    }
  });
};

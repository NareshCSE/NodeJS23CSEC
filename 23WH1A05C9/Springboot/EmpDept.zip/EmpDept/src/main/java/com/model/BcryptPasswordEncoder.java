package com.model;

public class BcryptPasswordEncoder {

	public String encode(String password) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.controllers;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.EmployeeDao;
import com.model.Employee;
import com.model.EmployeeLogin;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeDao empDao;
	
	@GetMapping("getEmployees")
	public List<Employee> getEmployees() {
		return empDao.getEmployees();
	}
	@GetMapping("getEmployeeById/{empId}")
	public Employee getEmployeeById(@PathVariable("empId") int empId) {
		return empDao.getEmployeeById(empId);
	}
	@GetMapping("getEmployeeByName/{empName}")
	public Employee getEmployeeByName(@PathVariable("empName") String empName) {
		return empDao.getEmployeeByName(empName);
	}
	
	@PostMapping("addEmployee")
	public Employee addEmployee(@RequestBody Employee emp) {
		return empDao.addEmployee(emp);
	}
	
	@PutMapping("updateEmployee")
	public Employee updateEmployee(@RequestBody Employee emp) {
		return empDao.updateEmployee(emp);
	}

	
	@DeleteMapping("deleteEmployeeById/{empId}")
	public String deleteEmployeeById(@PathVariable("empId") int empId) {
		empDao.deleteEmployeeById(empId);
		return "Employee Record Deleted Successfully!!";
	}
	
	
	@GetMapping("getEmployeeByEmailId/{emailId}")
	public Employee getEmployeeByEmailId(@PathVariable("emailId") String emailId) {
		return empDao.getEmployeeByEmailId(emailId);
	}
	
//	@GetMapping("employeeLogin/{emailId}/{password}")
//	public Employee employeeLogin(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
//		return empDao.employeeLogin(emailId, password);
//	}	
//	
	@PostMapping("empLogin")
	public Employee empLogin(@RequestBody EmployeeLogin emp) {
		return ((EmployeeDao) empDao).empLogin(emp);
	}


}


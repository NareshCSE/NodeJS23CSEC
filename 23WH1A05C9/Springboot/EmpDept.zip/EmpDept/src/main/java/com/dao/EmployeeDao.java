package com.dao;



import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.model.Employee;
import com.model.EmployeeLogin;

@Service
public class EmployeeDao {

	@Autowired
	EmployeeRepository empRepo;
	//private Object passwordEncoder;
	
	@Autowired
    private BCryptPasswordEncoder passwordEncoder;

	public List<Employee> getEmployees() {
		return empRepo.findAll();
	}
	public Employee getEmployeeById(int empId) {
		return empRepo.findById(empId).orElse(null);
	}
	
	public Employee addEmployee(Employee emp) {
		emp.setPassword(passwordEncoder.encode(emp.getPassword()));
		return empRepo.save(emp);	//Insert or Update
	}
	
	public Employee updateEmployee(Employee emp) {
		emp.setPassword(passwordEncoder.encode(emp.getPassword()));
		return empRepo.save(emp);	//Insert or Update
	}
	public Employee getEmployeeByName(String empName) {
		return empRepo.getEmployeeByName(empName).orElse(null);
	}
	public void deleteEmployeeById(int empId) {
		empRepo.deleteById(empId);
	}
	
	
	public Employee getEmployeeByEmailId(String emailId) {
		return empRepo.getEmployeeByEmailId(emailId).orElse(null);
	}

	public Employee empLogin(EmployeeLogin emp) {
		Employee existingEmp = empRepo.getEmployeeByEmailId(emp.getEmailId()).orElse(null);
        
        if (existingEmp != null && passwordEncoder.matches(emp.getPassword(), existingEmp.getPassword())) {
            return existingEmp;  // Password matches, return employee
        }
		// TODO Auto-generated method stub
		return null;
		// TODO Auto-generated method stub
	}
	
	
//	public Employee employeeLogin(String emailId, String password) {
//		return empRepo.employeeLogin(emailId, password).orElse(null);
//	}
//
//	public Employee empLogin(EmployeeLogin emp) {
//		return empRepo.empLogin(emp.getEmailId(), emp.getPassword());
//	}


}




package com.dao;


import java.util.Optional;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("from Employee where empName = :ename")
	Optional<Employee> getEmployeeByName(@Param("ename") String empName);
	
	
	@Query("from Employee where emailId = :emailId")
	Optional<Employee> getEmployeeByEmailId(@Param("emailId") String emailId);
		
	
	@Query("from Employee where emailId = :emailId and password = :password")
	Optional<Employee> employeeLogin(@Param("emailId") String emailId, @Param("password") String password);

	@Query("from Employee where emailId = :emailId and password = :password")
	Employee empLogin(@Param("emailId") String emailId, @Param("password") String password);
	
}






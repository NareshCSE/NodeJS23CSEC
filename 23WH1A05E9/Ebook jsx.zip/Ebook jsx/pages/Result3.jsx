
import React from 'react';

const Result3 = () => {
  return (
      <h1>Thanks,For your resgistering.</h1>
  );
};

export default Result3;
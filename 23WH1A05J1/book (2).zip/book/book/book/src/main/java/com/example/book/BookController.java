package com.example.book; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*; 
import java.util.List; 
import java.util.Optional; 
 
//@CrossOrigin(origins = "http://localhost:3000")
@RestController 
@RequestMapping("/employees") 
public class BookController { 
 
    @Autowired 
    private BookRepository bookRepo; 
    // I) Get all books                          
    @GetMapping("/getAllDetails") 
    public List<Book> getAllDetails() { 
        return bookRepo.findAll(); 
    } 
    
} 

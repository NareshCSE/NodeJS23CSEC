package com.example.bvrith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BvrithApplicationTests {

	@Test
	void contextLoads() {
	}

}

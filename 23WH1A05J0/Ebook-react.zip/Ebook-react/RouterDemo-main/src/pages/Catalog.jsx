import React from 'react';

const books = [
  { title: 'Book Title 1', author: 'John Doe', price: 10.99 },
  { title: 'Book Title 2', author: 'Jane Smith', price: 12.99 },
  { title: 'Book Title 3', author: 'Alice Brown', price: 8.99 },
];

const Catalog = () => {
  const addToCart = (book) => {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${book.title} added to cart!`);
  };

  return (
    <div className="container my-5" style={styles.container}>
      <h1 className="text-center text-primary mb-4">Catalog</h1>
      <div className="row">
        {books.map((book, idx) => (
          <div className="col-md-4 mb-4" key={idx}>
            <div className="card" style={styles.card}>
              <div className="card-body">
                <h5 className="card-title">{book.title}</h5>
                <p className="card-text">Author: {book.author}</p>
                <p className="card-text">Price: ${book.price.toFixed(2)}</p>
                <button
                  className="btn btn-primary"
                  onClick={() => addToCart(book)}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: '#ffffff',
    padding: '30px',
    borderRadius: '15px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  card: {
    borderRadius: '10px',
    transition: '0.3s',
  },
};

export default Catalog;

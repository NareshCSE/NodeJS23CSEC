import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import Cart from "./pages/Cart";
import Catalog from "./pages/Catalog";

const App = () => {
  return (
    <Router>
      {/* Simple navbar */}
      <nav style={{ padding: "1rem", background: "black"  }}>
        <Link to="/home" style={{ marginRight: "1rem" }}>Home</Link>
        <Link to="/catalog" style={{ marginRight: "1rem" }}>Catalog</Link>
        <Link to="/cart" style={{ marginRight: "1rem" }}>Cart</Link>
        <Link to="/contact">Contact</Link>
      </nav>

      {/* Route setup */}
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/catalog" element={<Catalog />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
};

export default App;

import React, { useState } from 'react';

const App = () => {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');

  const API_KEY = '76600624302245c8935131837251204'; // WeatherAPI key

  const getWeather = async () => {
    try {
      const res = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${city}&aqi=no`
      );
      if (!res.ok) throw new Error('City not found');
      const data = await res.json();
      setWeather(data);
      setError('');
    } catch (err) {
      setError(err.message);
      setWeather(null);
    }
  };

  return (
    <div className="weather-app">
      <h2>Weather Checker 🌦</h2>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button onClick={getWeather}>Get Weather</button>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {weather && (
        <div className="weather-info">
          <h3>{weather.location.name}, {weather.location.country}</h3>
          <p> Temp: {weather.current.temp_c} °C</p>
          <p> Condition: {weather.current.condition.text}</p>
          <p> Wind Speed: {weather.current.wind_kph} kph</p>
          <img src={weather.current.condition.icon} alt="weather-icon" />
        </div>
      )}
    </div>
  );
};

export default App;

/*npm i 
npm run dev 
npm install react-router-dom*/
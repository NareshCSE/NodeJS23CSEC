import React from "react";
import SumCalculator from "./components/SumCalculator";

function App() {
  return (
    <div>
      <SumCalculator />
    </div>
  );
}

export default App;

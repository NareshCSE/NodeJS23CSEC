
import React from 'react';

const Result = () => {
  return (
      <h1>Thanks,For your feedback.</h1>
  );
};

export default Result;
import React from 'react';
import { Link } from 'react-router-dom'; // Update the import to 'react-router-dom'
import './Header.css';
import logo from '../../../assets/logo.png'; // Replace this path with your actual logo path

const Header = () => {
  return (
    <header className="header">
      <div className="logo">
        <Link to="/">
          <img src={logo} alt="Vishnu Universal Learning Logo" />
        </Link>
      </div>
      <div className="title">
        <h1>BVRIT Registration Portal</h1>
      </div>
      <div className="nav">
        <ul>
          <li>
            <Link to="/registrationForm">Register</Link> {/* Change to the proper link */}
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/services">Services</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>
    </header>
  );
};

export default Header;
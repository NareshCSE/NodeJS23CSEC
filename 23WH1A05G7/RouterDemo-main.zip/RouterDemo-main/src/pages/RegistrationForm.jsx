import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import './styles.css';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    fname: '',
    email: '',
    pwd: '',
    number: '',
    dob: '',
    languages: [],
    gender: '',
    department: '',
    address: '',
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === 'checkbox') {
      setFormData({
        ...formData,
        languages: checked
          ? [...formData.languages, value]
          : formData.languages.filter((lang) => lang !== value),
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    navigate('/thank-you');
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-lg-8 col-md-10 col-sm-12 form-container">
          <h1>Registration Form</h1>
          <form onSubmit={handleSubmit}>
            {/* Name & Email */}
            <div className="row mb-3">
              <div className="col-md-6">
                <label htmlFor="fname">Name:</label>
                <input
                  type="text"
                  id="fname"
                  name="fname"
                  className="form-control"
                  value={formData.fname}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-md-6">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="form-control"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            {/* Password & Mobile */}
            <div className="row mb-3">
              <div className="col-md-6">
                <label htmlFor="pwd">Password:</label>
                <input
                  type="password"
                  id="pwd"
                  name="pwd"
                  className="form-control"
                  value={formData.pwd}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-md-6">
                <label htmlFor="number">Mobile Number:</label>
                <input
                  type="tel"
                  id="number"
                  name="number"
                  className="form-control"
                  value={formData.number}
                  onChange={handleChange}
                  pattern="\d{10}"
                  maxLength="10"
                  placeholder="Enter 10-digit number"
                  required
                />
              </div>
            </div>

            {/* Date of Birth */}
            <div className="row mb-3">
              <div className="col-md-6">
                <label htmlFor="dob">Date of Birth:</label>
                <input
                  type="date"
                  id="dob"
                  name="dob"
                  className="form-control"
                  value={formData.dob}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            {/* Languages Known */}
            <div className="row mb-3">
              <div className="col-md-12">
                <label>Languages Known:</label>
                <div className="language-container">
                  <div>
                    <input
                      type="checkbox"
                      id="language1"
                      name="language"
                      value="English"
                      onChange={handleChange}
                    />
                    <label htmlFor="language1">English</label>
                  </div>
                  <div>
                    <input
                      type="checkbox"
                      id="language2"
                      name="language"
                      value="Hindi"
                      onChange={handleChange}
                    />
                    <label htmlFor="language2">Hindi</label>
                  </div>
                  <div>
                    <input
                      type="checkbox"
                      id="language3"
                      name="language"
                      value="Telugu"
                      onChange={handleChange}
                    />
                    <label htmlFor="language3">Telugu</label>
                  </div>
                  <div>
                    <input
                      type="checkbox"
                      id="language4"
                      name="language"
                      value="Urdu"
                      onChange={handleChange}
                    />
                    <label htmlFor="language4">Urdu</label>
                  </div>
                </div>
              </div>
            </div>

            {/* Gender */}
            <div className="row mb-3">
              <div className="col-md-12">
                <label>Gender:</label>
                <div className="gender-container">
                  <div>
                    <input
                      type="radio"
                      id="male"
                      name="gender"
                      value="Male"
                      onChange={handleChange}
                    />
                    <label htmlFor="male">Male</label>
                  </div>
                  <div>
                    <input
                      type="radio"
                      id="female"
                      name="gender"
                      value="Female"
                      onChange={handleChange}
                    />
                    <label htmlFor="female">Female</label>
                  </div>
                  <div>
                    <input
                      type="radio"
                      id="other"
                      name="gender"
                      value="Other"
                      onChange={handleChange}
                    />
                    <label htmlFor="other">Other</label>
                  </div>
                </div>
              </div>
            </div>

            {/* Department */}
            <div className="row mb-3">
              <div className="col-md-6">
                <label htmlFor="Department">Select a Department:</label>
                <select
                  id="Department"
                  name="department"
                  className="form-select"
                  value={formData.department}
                  onChange={handleChange}
                  required
                >
                  <option value="">--Select--</option>
                  <option value="CSE">Computer Science and Engineering</option>
                  <option value="IT">Information Technology</option>
                  <option value="ECE">Electronics and Communication Engineering</option>
                  <option value="ME">Mechanical Engineering</option>
                  <option value="AE">Aerospace Engineering</option>
                </select>
              </div>
            </div>

            {/* Address */}
            <div className="row mb-3">
              <div className="col-md-12">
                <label htmlFor="address">Address:</label>
                <textarea
                  id="address"
                  name="address"
                  rows="4"
                  className="form-control"
                  value={formData.address}
                  onChange={handleChange}
                  placeholder="Enter your address here..."
                  required
                ></textarea>
              </div>
            </div>

            {/* Submit and Reset Buttons */}
            <div className="row mb-3">
              <div className="col-md-6 d-flex justify-content-center">
                <button type="submit" className="btn btn-primary">
                  <i className="fas fa-paper-plane"></i> Submit
                </button>
              </div>
              <div className="col-md-6 d-flex justify-content-center">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setFormData({})} // Reset form on click
                >
                  Reset
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RegistrationForm;
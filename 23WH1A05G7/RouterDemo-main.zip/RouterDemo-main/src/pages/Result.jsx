import React from 'react';

const Result= () => {
  return (
    <div className="result">
      
      <h2>Thanks for your valuable feedback!</h2>
      
    </div>
  );
};

export default Result;
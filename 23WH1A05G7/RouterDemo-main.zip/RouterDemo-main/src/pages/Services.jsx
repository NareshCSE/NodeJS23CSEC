import React from 'react';

const Services = () => {
  return (
    <div className="services">
      <h1>Our Services</h1>
      <p>We offer a wide range of services to meet your needs.</p>
      <ul>
        <li>Service 1: Description of service 1.</li>
        <li>Service 2: Description of service 2.</li>
        <li>Service 3: Description of service 3.</li>
        <li>Service 4: Description of service 4.</li>
      </ul>
    </div>
  );
};

export default Services;
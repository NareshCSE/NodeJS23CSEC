import { useState, useEffect } from "react";
import axios from "axios";

const Weather = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [city, setCity] = useState("London"); // Default city
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch weather data
  useEffect(() => {
    const fetchWeatherData = async () => {
      setLoading(true);
      setError(null);
      const apiKey = "a5409c1e6f863954966fe089cc38c6da"; // Replace with your OpenWeather API Key
      const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

      try {
        const response = await axios.get(weatherUrl);
        setWeatherData(response.data);
      } catch (err) {
        setError("Unable to fetch weather data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchWeatherData();
  }, [city]);

  return (
    <div>
      <h2>Weather in {city}</h2>
      <div>
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city"
        />
        <button onClick={() => setCity(city)}>Get Weather</button>
      </div>

      {loading && <p>Loading...</p>}

      {error && <p>{error}</p>}

      {weatherData && !loading && !error && (
        <div>
          <p>
            <strong>Temperature:</strong> {weatherData.main.temp}°C
          </p>
          <p>
            <strong>Weather:</strong> {weatherData.weather[0].description}
          </p>
          <p>
            <strong>Humidity:</strong> {weatherData.main.humidity}%
          </p>
          <p>
            <strong>Wind Speed:</strong> {weatherData.wind.speed} m/s
          </p>
        </div>
      )}
    </div>
  );
};

export default Weather;
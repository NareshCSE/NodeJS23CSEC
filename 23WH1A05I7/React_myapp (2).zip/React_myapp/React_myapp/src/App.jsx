import  { BrowserRouter, Routes, Route } from "react-router";
import Home from "./pages/Home";
import About from "./pages/About";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import AppLayout from "./components/layout/AppLayout/AppLayout";
import Result from "./pages/Result";
import Weather from "./pages/Weather";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route>
          <Route path='/*' element={<AppLayout />} >
          <Route index element={<Home />} />
          <Route path= 'home' element={<Home />} />
          <Route path= 'about' element={<About />} />
          <Route path= 'signup' element={<SignUp />} />
          <Route path= 'result' element={<Result/>} />
          <Route path= 'login' element={<Login/>} />
          <Route path='weather' element={<Weather/>}/>

        </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
export default App


